#include <iostream>
using namespace std;

int main(){
    int tab[] = {2,4,6,1};
    
    int rozmiar = *(&tab + 1);

    for(int *i = tab;i < rozmiar;++i){
        cout << *i << " ";
    }
    return 0;
}